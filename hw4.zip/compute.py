from collections import OrderedDict
from operator import itemgetter
import numpy as np

def calculatePageRankScore(theList):
    pageRank = []
    for i in range(len(theList)):
        newScores = OrderedDict()
        oldScores = OrderedDict()
        N = len(theList[i])
        B = 0.15 * (1/N)
        for node in theList[i]:
            oldScores[node] = 1/N
            newScores[node] = 1/N
        for iteration in range(10):
            for node in theList[i]:
                summation = 0
                for connectedNodes in theList[i][node]:
                    summation += theList[i][node][connectedNodes] / \
                                 sum([theList[i][connectedNodes][x] for x in theList[i][connectedNodes]]) * \
                                 oldScores[connectedNodes]
                newScores[node] = (0.85 * summation) + B
            oldScores = newScores.copy()
        pageRank.append(oldScores.copy())
    return pageRank


def calculateNGrams_PR(tokenUpdated, pageRank):
    nGrams = []
    for i in range(len(tokenUpdated)):
        myGrams = OrderedDict()
        for j in range(len(tokenUpdated[i])):
            if tokenUpdated[i][j] != "":
                if tokenUpdated[i][j] not in myGrams:
                    myGrams[tokenUpdated[i][j]] = pageRank[i][tokenUpdated[i][j]]
                if (j+1) < len(tokenUpdated[i]) and tokenUpdated[i][j+1] != "":
                    if (tokenUpdated[i][j] + " " + tokenUpdated[i][j+1]) not in myGrams:
                        myGrams[tokenUpdated[i][j] + " " + tokenUpdated[i][j+1]] = pageRank[i][tokenUpdated[i][j]] + pageRank[i][tokenUpdated[i][j+1]]

                    if (j+2) < len(tokenUpdated[i]) and tokenUpdated[i][j + 2] != "":
                        if (tokenUpdated[i][j] + " " + tokenUpdated[i][j + 1] + " " + tokenUpdated[i][j + 2]) not in myGrams:
                            myGrams[tokenUpdated[i][j] + " " + tokenUpdated[i][j + 1] + " " + tokenUpdated[i][j + 2]] = pageRank[i][tokenUpdated[i][j]] + \
                                                                                                                        pageRank[i][tokenUpdated[i][j + 1]] + \
                                                                                                                        pageRank[i][tokenUpdated[i][j+2]]
        myGrams = OrderedDict(sorted(myGrams.items(), key = itemgetter(1), reverse = True))
        nGrams.append(myGrams.copy())
    return nGrams


def calculateNGrams_TFIDF(tokenUpdated, documentModel, vocabulary):
    nGrams = []
    for i in range(len(tokenUpdated)):
        myGrams = OrderedDict()
        for j in range(len(tokenUpdated[i])):
            if tokenUpdated[i][j] != "":
                if tokenUpdated[i][j] not in myGrams:
                    myGrams[tokenUpdated[i][j]] = documentModel[i][vocabulary[tokenUpdated[i][j]]]
                if (j+1) < len(tokenUpdated[i]) and tokenUpdated[i][j+1] != "":
                    if (tokenUpdated[i][j] + " " + tokenUpdated[i][j+1]) not in myGrams:
                        myGrams[tokenUpdated[i][j] + " " + tokenUpdated[i][j+1]] = documentModel[i][vocabulary[tokenUpdated[i][j]]] + documentModel[i][vocabulary[tokenUpdated[i][j+1]]]

                    if (j+2) < len(tokenUpdated[i]) and tokenUpdated[i][j + 2] != "":
                        if (tokenUpdated[i][j] + " " + tokenUpdated[i][j + 1] + " " + tokenUpdated[i][j + 2]) not in myGrams:
                            myGrams[tokenUpdated[i][j] + " " + tokenUpdated[i][j + 1] + " " + tokenUpdated[i][j + 2]] = documentModel[i][vocabulary[tokenUpdated[i][j]]] + \
                                                                                                                        documentModel[i][vocabulary[tokenUpdated[i][j+1]]] + \
                                                                                                                        documentModel[i][vocabulary[tokenUpdated[i][j+2]]]
        myGrams = OrderedDict(sorted(myGrams.items(), key = itemgetter(1), reverse = True))
        nGrams.append(myGrams.copy())
    return nGrams


def calculateMRR(tokenUpdatedGold, nGrams):
    avgMRR = []
    top10MRR = np.zeros((len(nGrams), 10))
    for i in range(len(nGrams)):
        counter = 1
        for key in nGrams[i]:
            if key in tokenUpdatedGold[i]:
                mrr = 1/counter
                for j in range(counter-1, 10):
                    top10MRR[i][j] = mrr
                break
            counter += 1
            if counter > 10:
                break
    for i in range(10):
        avgMRR.append((sum(row[i] for row in top10MRR))/len(nGrams))
    return top10MRR, avgMRR


def buildInvertedIndex(tokenCollection):
    from collections import OrderedDict
    invertedIndex = OrderedDict()
    vocabulary = {}
    docSet = []
    index = 0
    for d in range(len(tokenCollection)):
        temp = set()
        for word in tokenCollection[d]:
            if word != "":
                temp.add(word)
                if word not in invertedIndex:
                    invertedIndex[word] = {}
                    invertedIndex[word][d] = 1
                    vocabulary[word] = index
                    index += 1
                else:
                    if d not in invertedIndex[word]:
                        invertedIndex[word][d] = 0
                    invertedIndex[word][d] += 1
        docSet.append(temp.copy())
    return invertedIndex, vocabulary, docSet


def buildVectorSpaceModel(tokenCollection, invertedIndex, vocabulary):
    import numpy
    import math
    N = len(tokenCollection)
    vectorSpaceModel = numpy.zeros((N, len(vocabulary)))
    for d in range(len(tokenCollection)):
        # max = 0
        # for w in docSet[d]:
        #     if invertedIndex[w][d] > max:
        #         max = invertedIndex[w][d]
        for term in tokenCollection[d]:
            if term != "" and term in vocabulary:
                vectorSpaceModel[d][vocabulary[term]] = (invertedIndex[term][d] if d in invertedIndex[term] else 0) * math.log2(N/len(invertedIndex[term]))
    return vectorSpaceModel
