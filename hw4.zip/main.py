import preprocess
import compute


def main(abstractPath, goldPath):
    import time
    start = time.time()

    dataAbstract, dataGold, stopWords = preprocess.getData(abstractPath, goldPath)

    tokenCollectionAbstract = preprocess.tokenizeData(dataAbstract)
    tokenUpdatedAbstract = preprocess.cleanDataAbstract(tokenCollectionAbstract[:], stopWords)
    tokenUpdatedGold = preprocess.cleanDataGold(dataGold)
    theList = preprocess.createAdjacencyList(tokenUpdatedAbstract[:])
    pageRank = compute.calculatePageRankScore(theList)
    nGrams_PR = compute.calculateNGrams_PR(tokenUpdatedAbstract, pageRank)
    top10MRR_PR, avgMRR_PR = compute.calculateMRR(tokenUpdatedGold, nGrams_PR)

    invertedIndex, vocabulary, docSet = compute.buildInvertedIndex(tokenUpdatedAbstract)
    documentModel = compute.buildVectorSpaceModel(tokenUpdatedAbstract, invertedIndex, vocabulary)
    nGrams_TFIDF = compute.calculateNGrams_TFIDF(tokenUpdatedAbstract, documentModel, vocabulary)
    top10MRR_TFIDF, avgMRR_TFIDF = compute.calculateMRR(tokenUpdatedGold, nGrams_TFIDF)

    print("TOP 10 MRR scores for Page Rank:")
    for i in range(10):
        print("\t\tMRR for TOP "+str(i+1)+": " + str(avgMRR_PR[i]))
    print("\n\n")
    print("TOP 10 MRR scores for TF-IDF:")
    for i in range(10):
        print("\t\tMRR for TOP "+str(i+1)+": " + str(avgMRR_TFIDF[i]))
    end = time.time()
    # print(end - start)


if __name__ == '__main__':
    import sys
    main(sys.argv[1], sys.argv[2])
