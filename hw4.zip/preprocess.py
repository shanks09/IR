import numpy as np
import nltk
from nltk.stem import PorterStemmer
from collections import OrderedDict


def getData(abstractPath, goldPath):
    import os
    setFilesAbstract = set(os.listdir('./' + abstractPath))
    arrFilesGold = os.listdir('./' + goldPath)
    fileList = []
    dataAbstract = []
    dataGold = []
    stopWords = set()
    # escapes = ''.join([chr(char) for char in range(1, 32)])


    punctuation = '!"#$%&\'()*+,./:;<=>?@[\\]^`{|}~'
    # punctuation = '!"#$%&\'()*+,-./:;<=>?@[\\]^_`{|}~'
    table = str.maketrans(punctuation, ' '*len(punctuation))
    # for i in range(len(data)):
    #     data[i] = data[i].translate(table)


    for file in arrFilesGold:
        if file in setFilesAbstract:
            fileList.append(file)
    fileList.sort(key=int)
    dd = sorted(fileList)

    for file in fileList:
        with open("./" + abstractPath + "/" + file) as fobj:
            dataAbstract.append(fobj.read().lower().translate(table))

        with open("./" + goldPath + "/" + file) as fobj:
            dataGold.append(fobj.read().lower().strip().split("\n"))

    with open("./stopwords.txt") as fobj:
        for line in fobj:
            stopWords.add(line.strip())

    return dataAbstract, dataGold, stopWords


def tokenizeData(data):
    tokens = []
    for i in range(len(data)):
        tokens.append([x for x in nltk.word_tokenize(data[i]) if x != '_'])

    return tokens


def cleanDataAbstract(tokenCollection, stopWords):
    ps = PorterStemmer()
    for i in range(len(tokenCollection)):
        for j in range(len(tokenCollection[i])):
            tempWord = tokenCollection[i][j]
            if tempWord.endswith(("_nn", "_nns", "_nnp", "_nnps", "_jj")):
                tempWord = tempWord[:tempWord.rfind("_")]
                if tempWord in stopWords:
                    tempWord = ""
                else:
                    tempWord = ps.stem(tempWord)
                    if tempWord in stopWords:
                        tempWord = ""
            else:
                tempWord = ""
            tokenCollection[i][j] = tempWord
    return tokenCollection


def cleanDataGold(dataGold):
    tokenCollection = []
    ps = PorterStemmer()
    for i in range(len(dataGold)):
        myList = []
        for j in range(len(dataGold[i])):
            if len(dataGold[i][j].split(" ")) == 1:
                myList.append(ps.stem(dataGold[i][j]))
            else:
                tempWord = ""
                for word in dataGold[i][j].split(" "):
                    tempWord += ps.stem(word) + " "
                myList.append(tempWord.strip())

        tokenCollection.append(myList[:])
    return tokenCollection


def createAdjacencyList(tokenCollection):
    theList = []
    for i in range(len(tokenCollection)):
        mydict = OrderedDict()
        for j in range(len(tokenCollection[i])):
            if tokenCollection[i][j] != "":
                if tokenCollection[i][j] not in mydict:
                    mydict[tokenCollection[i][j]] = OrderedDict()

                if j-1 >= 0 and tokenCollection[i][j-1] != "":
                    if tokenCollection[i][j-1] not in mydict[tokenCollection[i][j]]:
                        mydict[tokenCollection[i][j]][tokenCollection[i][j-1]] = 0
                    mydict[tokenCollection[i][j]][tokenCollection[i][j - 1]] += 1
                if j+1 < len(tokenCollection[i]) and tokenCollection[i][j+1] != "":
                    if tokenCollection[i][j + 1] not in mydict[tokenCollection[i][j]]:
                        mydict[tokenCollection[i][j]][tokenCollection[i][j + 1]] = 0
                    mydict[tokenCollection[i][j]][tokenCollection[i][j + 1]] += 1
        theList.append(mydict.copy())
    return theList
