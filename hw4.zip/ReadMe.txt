                                    CS 582 Information Retrieval -- HW 4 (READ ME)


--  CODE BREAKDOWN --
The code is modularized into 3 files :

1. main.py: This file does alot of function calls to the methods in other 2 files. Methods in this file:
    > main(): It is the starting point of our program. It just calls other methods. (No computation done here)

2. preprocess.py: This file contains 5 methods, which are pretty much self-explanatory:
	> getData(abstractPath, goldPath):This method takes both abstract and gold path and reads them. Converts all to lower case, put "cranfieldDocs" data into a list of strings, stopwords data into a set, relevance doc into a dictionary, queries into a list and returns them all.

	> tokenizeData(data): This method tokenizes the data and returns a list of lists containing individual tokens for each document.
	> cleanDataAbstract(tokenCollection, stopWords): This methods cleans the abstract data while still maintaining indexing of words adjacency
	> cleanDataGold(dataGold): This cleans gold data and stem them.
	> createAdjacencyList(tokenCollection): This creats the actual graph in the form of an adjacency list.


3. compute.py: This file contains 7 methods::
	> calculatePageRankScore(theList): This computes the page rank scores for the texts.
	> calculateNGrams_PR(tokenUpdated, pageRank):This create n-Grams (upto 3) for the page rank scores and sort them in descending orser
	> calculateNGrams_TFIDF(tokenUpdated, documentModel, vocabulary): This create n-Grams (upto 3) for the TF-IDF scores and sort them in descending orser
	> calculateMRR(tokenUpdatedGold, nGrams):This cmputes the top myy scores for the n-Grams (be it for page rank of TFI_IDF)
	> buildInvertedIndex(tokenCollection): This method builds the inverted index of the collection using nested HashMaps for better efficiency.
	> buildVectorSpaceModel(tokenCollection, invertedIndex, vocabulary): This method creates the TF-IDF matrix of the collection.

--  HOW TO RUN --
    -> The code will run through the "main.py" file as it has the main method.
    -> The code receives two command line arguments which is the relative folder path of both abstract and gold documents. The path is relative so, if you are just putting the folder in the root directory itself then just type in the folder names as the argument.
	-> For adjacency, I am considering the entire document as a sequence.
	-> Also NO need to delete files from the abstract folder. The code itself searches for common files between the 2 olders (Gold & Abstract) and then do the computation
	-> Other required files include 2 python files (preprocess.py and compute.py) and "stopwords.txt" which are placed in the same folder as main.py.
    -> That's it!
