                                    CS 582 Information Retrieval -- HW 2 (READ ME)


--  CODE BREAKDOWN --
The code is modularized into 3 files :

1. main.py: This file does alot of function calls to the methods in other 2 files. Methods in this file:
    > main(): It is the starting point of our program. It just calls other methods. (No computation done here)

2. preprocess.py: This file contains 6 methods, which are pretty much self-explanatory:
	> getData(path):This method reads all SGML formatted files inside folder path given, "queries.txt", "relevance.txt" and "stopwords.txt" file. Converts all to lower case, put "cranfieldDocs" data into a list of strings, stopwords data into a set, relevance doc into a dictionary, queries into a list and returns them all.
	> removePunctuation(data): This method removes punctuations from the data.
	> removeDigits(data: This method removes digits from the data.
	> tokenizeData(data): This method tokenizes the data and returns a list of lists containing individual tokens for each document.
	> removeStopWords(tokenCollection, stopWords): This methods removes the stop words from all the tokens in the collection.
	> performStemming(tokenCollection): This methods stemms all the tokens in the collection(Used Porter stemmer of NTLK)

3. compute.py: This file contains 7 methods::
	> buildInvertedIndex(tokenCollection): This method builds the inverted index of the collection using nested HashMaps for better efficiency.
	> buildVectorSpaceModel(tokenCollection, invertedIndex, vocabulary): This method creates the TF-IDF matrix of the collection.
	> transformIntoVectorSpaceModel(tokenQueries, invertedIndex, vocabulary, len(tokenCollection)): This method transforms the query into a TF-IDF vector for efficient similarity check.
	> getCosineSimilarity(documentModel, queryModel, vocabulary, tokenQueries, docSet): This method computes the similarity between the queries and the documents.
	> writeTop500DocumentPairs(cosineSimilaritySorted): This method writes the top 500 relevant documents for each query into the file "output_relevance.txt"
	> calculatePrecisionRecall(cosineSimilaritySorted, relevance, top): This method calculates the Precision/Recall/Avg. Precision/Avg. Recall for the top(10,50,100,500) documents.
	> writeAveragePrecisionRecall(cosineSimilaritySorted, relevance): This method calls the above method and writes the Precision/Recall/Avg. Precision/Avg. Recall into the file "output_precision_recall.txt"
	



--  HOW TO RUN --
    -> The code will run through the "main.py" file as it has the main method.
    -> The code receives one command line argument which is the folder path containing all the documents. The path is relative so, if you are just putting the folder in the root directory itself then just type in the folder name as the argument.
	-> Also the "cranfieldDocs" folder should only contain the files which are needed to be read for the collection (the code will read all files inside the "cranfieldDocs" folder)
	-> Other required files include 2 python files (preprocess.py and compute.py), "queries.txt", "relevance.txt", "stopwords.txt" which are placed in the same folder as main.py.
    -> After the execution, the output is generated into 2 files:
		> output_relevance.txt:			This file lists the top 500 documents for all the 10 queries in decreasing order of their relevance.
		> output_precision_recall.txt:	This file contains the Precision/Recall values for all 10 queries at different levels(10, 50 100, 500)
    -> That's it!


