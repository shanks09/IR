import preprocess
import compute


def main(path):
    data, stopWords, queries, relevance = preprocess.getData(path)
    data = preprocess.removePunctuation(data)
    data = preprocess.removeDigits(data)

    tokenCollection = preprocess.tokenizeData(data)
    tokenCollection = preprocess.removeStopWords(tokenCollection, stopWords)
    tokenCollection = preprocess.performStemming(tokenCollection)
    tokenCollection = preprocess.removeStopWords(tokenCollection, stopWords)

    queries = preprocess.removePunctuation(queries)
    queries = preprocess.removeDigits(queries)
    tokenQueries = preprocess.tokenizeData(queries)
    tokenQueries = preprocess.removeStopWords(tokenQueries, stopWords)
    tokenQueries = preprocess.performStemming(tokenQueries)
    tokenQueries = preprocess.removeStopWords(tokenQueries, stopWords)

    invertedIndex, vocabulary, docSet = compute.buildInvertedIndex(tokenCollection)
    documentModel = compute.buildVectorSpaceModel(tokenCollection, invertedIndex, vocabulary)
    queryModel = compute.transformIntoVectorSpaceModel(tokenQueries, invertedIndex, vocabulary, len(tokenCollection))

    cosineSimilarity, cosineSimilaritySorted = compute.getCosineSimilarity(documentModel, queryModel, vocabulary, tokenQueries, docSet)
    compute.writeTop500DocumentPairs(cosineSimilarity, cosineSimilaritySorted)
    compute.writeAveragePrecisionRecall(cosineSimilaritySorted, relevance)


if __name__ == '__main__':
    import sys
    main(sys.argv[1])
