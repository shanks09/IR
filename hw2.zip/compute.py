def buildInvertedIndex(tokenCollection):
    from collections import OrderedDict
    invertedIndex = OrderedDict()
    vocabulary = {}
    docSet = []
    index = 0
    for d in range(len(tokenCollection)):
        temp = set()
        for word in tokenCollection[d]:
            temp.add(word)
            if word not in invertedIndex:
                invertedIndex[word] = {}
                invertedIndex[word][d] = 1
                vocabulary[word] = index
                index += 1
            else:
                if d not in invertedIndex[word]:
                    invertedIndex[word][d] = 0
                invertedIndex[word][d] += 1
        docSet.append(temp.copy())
    return invertedIndex, vocabulary, docSet


def buildVectorSpaceModel(tokenCollection, invertedIndex, vocabulary):
    import numpy
    import math
    N = len(tokenCollection)
    vectorSpaceModel = numpy.zeros((N, len(vocabulary)))
    for d in range(len(tokenCollection)):
        # max = 0
        # for w in docSet[d]:
        #     if invertedIndex[w][d] > max:
        #         max = invertedIndex[w][d]
        for term in tokenCollection[d]:
            if term in vocabulary:
                vectorSpaceModel[d][vocabulary[term]] = (invertedIndex[term][d] if d in invertedIndex[term] else 0) * math.log2(N/len(invertedIndex[term]))
    return vectorSpaceModel


def transformIntoVectorSpaceModel(tokenCollection,  invertedIndex, vocabulary, N):
    import numpy
    import math
    vectorSpaceModel = numpy.zeros((len(tokenCollection), len(vocabulary)))
    # collection = getFrequencyPerDocument(tokenCollection)
    for d in range(len(tokenCollection)):
        for term in tokenCollection[d]:
            if term in vocabulary:
                vectorSpaceModel[d][vocabulary[term]] = math.log2(N/len(invertedIndex[term]))
    return vectorSpaceModel


def getCosineSimilarity(documentModel, queryModel, vocabulary, tokenQueries, docSet):
    import numpy
    import math
    cs = numpy.zeros((queryModel.shape[0], documentModel.shape[0]))
    for i in range(queryModel.shape[0]):
        for d in range(documentModel.shape[0]):
            a = 0
            b = 0
            c = 0
            for term in tokenQueries[i]:
                if term in vocabulary:
                    a += (documentModel[d][vocabulary[term]] * queryModel[i][vocabulary[term]])
                    c += queryModel[i][vocabulary[term]] ** 2
            for term in docSet[d]:
                b += documentModel[d][vocabulary[term]] ** 2
            cs[i][d] = (a/(math.sqrt(b)*math.sqrt(c)))
    return cs, cs.argsort()


def writeTop500DocumentPairs(cosineSimilarity, cosineSimilaritySorted):
    with open("./output_relevance.txt", 'w') as fobj:
        for i in range(len(cosineSimilaritySorted)):
            cs = cosineSimilarity[i]
            s = "Query " + str(i+1) + ": \n" + str([x+1 for x in cosineSimilaritySorted[i][::-1][:500]]) + "\n\n\n\n"
            fobj.write(s)


def calculatePrecisionRecall(cosineSimilaritySorted, relevance, top):
    import numpy as np
    pr = {}
    pList=[]
    rList=[]
    N = len(cosineSimilaritySorted[0])

    for i in range(len(relevance)):
        count = 0
        for j in range(N-1, N-1-top, -1):
            if (cosineSimilaritySorted[i][j]+1) in relevance[i+1]:
                count += 1

        p = count / top
        r = count / len(relevance[i+1])
        pList.append(p)
        rList.append((r))
    pr["p"] = pList[:]
    pr["r"] = rList[:]
    pr["ap"] = np.array(pList).mean()
    pr["ar"] = np.array(rList).mean()
    return pr.copy()


def writeAveragePrecisionRecall(cosineSimilaritySorted, relevance):
    pr = {}
    pr[10] = calculatePrecisionRecall(cosineSimilaritySorted, relevance, 10)
    pr[50] = calculatePrecisionRecall(cosineSimilaritySorted, relevance, 50)
    pr[100] = calculatePrecisionRecall(cosineSimilaritySorted, relevance, 100)
    pr[500] = calculatePrecisionRecall(cosineSimilaritySorted, relevance, 500)

    with open("./output_precision_recall.txt", 'w') as fobj:
        for key in pr:
            fobj.write("\nTop "+str(key)+ " documents in rank list")
            for j in range(len(relevance)):
                fobj.write('\nQuery: ' + str(j+1) + "\t\tPr: " + str(pr[key]["p"][j]) + "\t\tRe: " + str(pr[key]["r"][j]))
            fobj.write("\nAvg Preciion: \t" + str(pr[key]["ap"]))
            fobj.write("\nAvg Recall: \t" + str(pr[key]["ar"]))
            fobj.write("\n\n")


# def getFrequencyPerDocument(tokenCollection):
#     collection = []
#     for d in tokenCollection:
#         vocabDict = {}
#         for term in d:
#             if term not in vocabDict:
#                 vocabDict[term] = 0
#             vocabDict[term] += 1
#         collection.append(vocabDict.copy())
#     return collection


# def calculateFrequency(tokenCollection):
#     vocabDict = {}
#     for d in tokenCollection:
#         for word in d:
#             if word not in vocabDict:
#                 vocabDict[word] = 0
#             vocabDict[word] += 1
#
#     from collections import OrderedDict
#     from operator import itemgetter
#     return OrderedDict(sorted(vocabDict.items(), key=itemgetter(1), reverse=True))


# def setupTF_IDF(tokenCollection, tokenQueries):
#     from sklearn.feature_extraction.text import TfidfVectorizer
#     def dummy_fun(doc):
#         return doc
#
#     tfidf = TfidfVectorizer(
#         analyzer='word',
#         tokenizer=lambda doc: doc,
#         preprocessor=lambda doc: doc,
#         token_pattern=None)
#     # txt_fitted = tfidf.fit(tokenCollection).toarray()
#     txt_transformed = tfidf.fit_transform(tokenCollection).toarray()
#     query = tfidf.transform(tokenQueries).toarray()
#
#
#     from sklearn.metrics.pairwise import linear_kernel
#     from sklearn.metrics.pairwise import cosine_similarity
#     a = cosine_similarity(query[0:1], txt_transformed).argsort()
#     min = a[0][-1]
#     max = a[0][0]
#
#     cosine_similarities = linear_kernel(query[0:1], txt_transformed).flatten().argsort()
#     min = cosine_similarities[-1]
#     max = cosine_similarities[0]
#
#     print("")
