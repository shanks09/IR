import nltk
from nltk.stem import PorterStemmer
from bs4 import BeautifulSoup

def getData(path):
    import os
    arrFiles = os.listdir('./'+path)
    data = []
    stopWords = set()
    relevance = {}
    queries = []
    # escapes = ''.join([chr(char) for char in range(1, 32)])
    for file in arrFiles:
        with open("./cranfieldDocs/"+file) as fobj:
            d = fobj.read().lower()
            soup = BeautifulSoup(d, "lxml")
            txt = soup('title')[0].text.strip() + ' ' + soup('text')[0].text.strip()
            data.append(txt)
    with open("./stopwords.txt") as fobj:
        for line in fobj:
            stopWords.add(line.strip())

    with open("./queries.txt") as fobj:
        for line in fobj:
            queries.append(line.strip())

    with open("./relevance.txt") as fobj:
        for line in fobj:
            arr = list(map(int, line.split()))
            if arr[0] in relevance:
                relevance[arr[0]].append(arr[1])
            else:
                relevance[arr[0]] = [arr[1]]

    return data, stopWords, queries, relevance


def removePunctuation(data):
    import string
    table = str.maketrans(string.punctuation, ' '*len(string.punctuation))
    for i in range(len(data)):
        data[i] = data[i].translate(table)
    return data


def removeDigits(data):
    from string import digits
    table = str.maketrans(digits, ' '*len(digits))
    for i in range(len(data)):
        data[i] = data[i].translate(table)
    return data


def tokenizeData(data):
    tokens = []
    for i in range(len(data)):
        tokens.append(nltk.word_tokenize(data[i]))
    return tokens


def removeStopWords(tokenCollection, stopWords):
    tokensMinusStopWords = []
    for d in tokenCollection:
        temp = []
        for word in d:
            if word not in stopWords and len(word) > 2:
                temp.append(word)
        tokensMinusStopWords.append(temp[:])
    return tokensMinusStopWords


def performStemming(tokenCollection):
    ps = PorterStemmer()
    tokensStemmed = []
    for d in tokenCollection:
        temp = []
        for word in d:
            temp.append(ps.stem(word))
        tokensStemmed.append(temp[:])
    return tokensStemmed
